package mk.ukim.finki.wp.june2025g1.model.exceptions;

public class InvalidStartupIdException extends RuntimeException {
}