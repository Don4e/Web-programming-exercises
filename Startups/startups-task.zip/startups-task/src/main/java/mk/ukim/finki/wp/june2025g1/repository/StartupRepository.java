package mk.ukim.finki.wp.june2025g1.repository;

public interface StartupRepository {
}
