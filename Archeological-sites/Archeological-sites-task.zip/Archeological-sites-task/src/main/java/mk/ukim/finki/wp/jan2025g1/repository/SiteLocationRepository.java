package mk.ukim.finki.wp.jan2025g1.repository;

public interface SiteLocationRepository {
}
