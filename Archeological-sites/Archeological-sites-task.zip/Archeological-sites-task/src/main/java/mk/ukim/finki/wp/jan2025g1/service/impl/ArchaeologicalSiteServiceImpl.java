package mk.ukim.finki.wp.jan2025g1.service.impl;

public class ArchaeologicalSiteServiceImpl {
}
