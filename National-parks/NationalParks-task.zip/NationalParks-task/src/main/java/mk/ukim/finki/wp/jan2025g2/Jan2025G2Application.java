package mk.ukim.finki.wp.jan2025g2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jan2025G2Application {

    public static void main(String[] args) {
        SpringApplication.run(Jan2025G2Application.class, args);
    }

}
