package mk.ukim.finki.wp.kol2025g2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Kol2025G2Application {

    public static void main(String[] args) {
        SpringApplication.run(Kol2025G2Application.class, args);
    }

}
