package mk.ukim.finki.wp.kol2025g3.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
public class Expense {

    private Long id;

    private String title;

    private LocalDate dateCreated;

    private Double amount;

    private Integer daysToExpire;

    private ExpenseCategory expenseCategory;

    private Vendor vendor;

    public Expense(String title, LocalDate dateCreated, Double amount, Integer daysToExpire, ExpenseCategory expenseCategory, Vendor vendor) {
        this.title = title;
        this.dateCreated = dateCreated;
        this.amount = amount;
        this.daysToExpire = daysToExpire;
        this.expenseCategory = expenseCategory;
        this.vendor = vendor;
    }

}
