package mk.ukim.finki.wp.kol2025g3.model.exceptions;

public class InvalidExpenseIdException extends RuntimeException {
}
