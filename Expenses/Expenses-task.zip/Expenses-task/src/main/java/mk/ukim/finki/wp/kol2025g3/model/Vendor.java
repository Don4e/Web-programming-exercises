package mk.ukim.finki.wp.kol2025g3.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Vendor {

    private Long id;

    private String name;

    public Vendor(String name) {
        this.name = name;
    }
}
