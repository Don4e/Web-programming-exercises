package mk.ukim.finki.wp.kol2025g3.repository;

public interface ExpenseRepository {
}
